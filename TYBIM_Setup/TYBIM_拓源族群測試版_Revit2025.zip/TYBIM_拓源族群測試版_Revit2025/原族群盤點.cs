try {
document=document.Application.Documents.Cast<Document>().Single(d=>d.IsFamilyDocument && d.Title=="圓形水管牆開口");
if(!document.IsFamilyDocument) throw new Exception("Expected family");
var fm=document.FamilyManager;
var rows=new List<object>();
using(var tx=new Transaction(document,"Inspect defaults (rollback)")) {
tx.Start();
if(fm.CurrentType==null) fm.NewType("Inspection");
foreach(FamilyParameter p in fm.Parameters) {
 string val=""; try { val=fm.CurrentType.AsValueString(p); if(p.StorageType==StorageType.String)val=fm.CurrentType.AsString(p); if(p.StorageType==StorageType.ElementId) {var id=fm.CurrentType.AsElementId(p); val=id.ToString()+":"+document.GetElement(id)?.Name;} }catch{}
 rows.Add(new {name=p.Definition.Name,id=p.Id.Value,instance=p.IsInstance,shared=p.IsShared,guid=p.IsShared?p.GUID.ToString():null,storage=p.StorageType.ToString(),spec=p.Definition.GetDataType().TypeId,formula=p.Formula,value=val,readOnly=p.IsReadOnly,userModifiable=p.UserModifiable});
}
tx.RollBack(); }
var branded=new List<object>();
var named=new List<object>();
foreach(var e in new FilteredElementCollector(document).WherePasses(new LogicalOrFilter(new ElementIsElementTypeFilter(),new ElementIsElementTypeFilter(true))).ToElements()) {
 if(e is Material || e is Family || e is TextNote || e is GraphicsStyle || e is FamilySymbol) named.Add(new {id=e.Id.Value,kind=e.GetType().Name,name=e.Name,text=(e as TextNote)?.Text});
 foreach(Parameter p in e.Parameters) {if(p.StorageType!=StorageType.String)continue; var s=p.AsString(); if(!string.IsNullOrEmpty(s) && (s.Contains("中興")||s.ToLowerInvariant().Contains("sino")||s.Contains("CQ824")||s.Contains("@")||s.Contains("http")))branded.Add(new {id=e.Id.Value,kind=e.GetType().Name,name=e.Name,param=p.Definition.Name,value=s});}
}
return new {title=document.Title,category=document.OwnerFamily.FamilyCategory.Name,placement=document.OwnerFamily.FamilyPlacementType.ToString(),parameters=rows,namedElements=named,brandMatches=branded};

} catch(Exception ex) { return ex.ToString(); }


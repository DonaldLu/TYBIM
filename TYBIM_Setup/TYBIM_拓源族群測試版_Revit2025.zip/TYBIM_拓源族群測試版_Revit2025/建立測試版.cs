try {
var path=@"C:\Prj\Revit\TYBIM\TYBIM_Setup\拓源數位科技 V1.1.5\自動開口_測試_勿外流\TYBIM_拓源測試版_Revit2025\圓形水管牆開口.rfa";
var fd=document.Application.OpenDocumentFile(path);
try {
var fm=fd.FamilyManager;
var old=fm.Parameters.Cast<FamilyParameter>().Where(p=>p.Id.Value>0).ToDictionary(p=>p.Definition.Name,p=>new {spec=p.Definition.GetDataType().TypeId,instance=p.IsInstance,guid=p.IsShared?p.GUID.ToString():null});
using(var tx=new Transaction(fd,"建立拓源族群測試版")) {
tx.Start();
if(fm.CurrentType==null)fm.NewType("圓形水管牆開口");
var gap=fm.AddParameter("拓源_單側預留間隙",GroupTypeId.Geometry,SpecTypeId.Length,true);
fm.Set(gap,15.0/304.8);
fm.SetFormula(fm.get_Parameter("預設圓形套管直徑"),"水管直徑 + 2 * 拓源_單側預留間隙");
fm.SetFormula(fm.get_Parameter("水管含保溫時圓形套管直徑"),"水管直徑 + 2 * (保溫層厚度 + 拓源_單側預留間隙)");
var version=fm.AddParameter("拓源_族庫版本",GroupTypeId.IdentityData,SpecTypeId.String.Text,false); fm.Set(version,"TYBIM-WALL-ROUND-TEST-01");
var usage=fm.AddParameter("拓源_用途",GroupTypeId.IdentityData,SpecTypeId.String.Text,true);fm.Set(usage,"牆穿管套管／開口定位");
fm.Set(fm.get_Parameter(BuiltInParameter.ALL_MODEL_MANUFACTURER),"拓源數位科技");
fm.Set(fm.get_Parameter(BuiltInParameter.ALL_MODEL_MODEL),"TYBIM-WALL-ROUND");
fm.Set(fm.get_Parameter(BuiltInParameter.ALL_MODEL_DESCRIPTION),"拓源圓形水管牆開口；保留自動開口寫入介面；測試版");
fm.Set(fm.get_Parameter(BuiltInParameter.ALL_MODEL_TYPE_COMMENTS),"拓源專用測試版；指定直徑優先；預留間隙預設單側15mm");
var source=fd.GetElement(fm.CurrentType.AsElementId(fm.get_Parameter("圓形套管材質"))) as Material;
var mat=source.Duplicate("TYBIM_套管_鍍鋅鋼");fm.Set(fm.get_Parameter("圓形套管材質"),mat.Id);
fd.Regenerate();
foreach(var pair in old){var p=fm.get_Parameter(pair.Key);if(p==null||p.Definition.GetDataType().TypeId!=pair.Value.spec||p.IsInstance!=pair.Value.instance||(p.IsShared?p.GUID.ToString():null)!=pair.Value.guid)throw new Exception("Schema changed: "+pair.Key);}
tx.Commit(); }
var flex=new List<object>();
using(var tx=new Transaction(fd,"Flex test rollback")) {
tx.Start();
foreach(var c in new[]{new[]{50.0,0.0,0.0,80.0},new[]{50.0,25.0,0.0,130.0},new[]{50.0,25.0,150.0,150.0},new[]{100.0,0.0,200.0,200.0},new[]{200.0,0.0,300.0,300.0}}){
fm.Set(fm.get_Parameter("水管直徑"),c[0]/304.8);fm.Set(fm.get_Parameter("保溫層厚度"),c[1]/304.8);fm.Set(fm.get_Parameter("指定圓形套管直徑"),c[2]/304.8);fm.Set(fm.get_Parameter("牆厚度"),200.0/304.8);fd.Regenerate();
var actual=fm.CurrentType.AsDouble(fm.get_Parameter("圓形套管直徑")).Value*304.8;if(Math.Abs(actual-c[3])>0.001)throw new Exception("Flex mismatch");
flex.Add(new{pipe=c[0],insulation=c[1],specified=c[2],actual}); }
tx.RollBack(); }
var scan=new List<string>();
foreach(var e in new FilteredElementCollector(fd).WherePasses(new LogicalOrFilter(new ElementIsElementTypeFilter(),new ElementIsElementTypeFilter(true))).ToElements()) {
if((e.Name??"").Contains("中興")||(e.Name??"").ToLowerInvariant().Contains("sinotech"))scan.Add(e.Name);
foreach(Parameter p in e.Parameters)if(p.StorageType==StorageType.String){var s=p.AsString()??"";if(s.Contains("中興")||s.ToLowerInvariant().Contains("sinotech"))scan.Add(s);}}
if(scan.Count>0)throw new Exception("Brand text remains");
var options=new SaveAsOptions{OverwriteExistingFile=true,Compact=true,MaximumBackups=1};fd.SaveAs(path,options);
return new{path,schemaPreserved=old.Count,flex,brandMatches=scan,forms=new FilteredElementCollector(fd).OfClass(typeof(GenericForm)).Cast<GenericForm>().Select(f=>new{kind=f.GetType().Name,solid=f.IsSolid}).ToArray()};
}finally{fd.Close(false);}
}catch(Exception ex){return new{error=ex.ToString()};}

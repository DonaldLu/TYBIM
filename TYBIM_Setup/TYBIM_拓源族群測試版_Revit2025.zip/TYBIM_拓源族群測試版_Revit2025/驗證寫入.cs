try {
var path=@"C:\Prj\Revit\TYBIM\TYBIM_Setup\拓源數位科技 V1.1.5\自動開口_測試_勿外流\TYBIM_拓源測試版_Revit2025\圓形水管牆開口.rfa";
var checks=new List<object>();
using(var group=new TransactionGroup(document,"拓源開口寫入測試（全部還原）")) {
group.Start(); Family fam;
using(var tx=new Transaction(document,"Load test family")){tx.Start();if(!document.LoadFamily(path,out fam))throw new Exception("Load failed");tx.Commit();}
var symbol=(FamilySymbol)document.GetElement(fam.GetFamilySymbolIds().First());
if(fam.Name!="圓形水管牆開口"||symbol.Name!="圓形水管牆開口")throw new Exception("Hardcoded name mismatch");
using(var tx=new Transaction(document,"Test actual instance writes")) {
tx.Start();symbol.Activate();document.Regenerate();
var level=new FilteredElementCollector(document).OfClass(typeof(Level)).Cast<Level>().OrderBy(l=>l.Elevation).First();
foreach(var diameter in new[]{80.0,150.0,300.0}) {
var fi=document.Create.NewFamilyInstance(new XYZ(diameter/100,0,1),symbol,level,Autodesk.Revit.DB.Structure.StructuralType.NonStructural);
fi.LookupParameter("水管直徑").Set(50.0/304.8);
fi.LookupParameter("指定圓形套管直徑").Set(diameter/304.8);
fi.LookupParameter("牆厚度").Set(200.0/304.8);
fi.LookupParameter("圓形牆開口流水號").Set((int)diameter);
fi.LookupParameter("位置").Set("FL1");
fi.LookupParameter("專業代碼").Set("TYBIM-TEST");
fi.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS).Set("TYBIM_TEST_PIPE_101_WALL_201");
var off=fi.get_Parameter(BuiltInParameter.INSTANCE_FREE_HOST_OFFSET_PARAM)??fi.get_Parameter(BuiltInParameter.INSTANCE_ELEVATION_PARAM);if(off==null||off.IsReadOnly)throw new Exception("Elevation unavailable");off.Set(1500.0/304.8);
fi.LookupParameter("圓形套管底部高程").Set((1500.0-diameter/2).ToString(System.Globalization.CultureInfo.InvariantCulture));
document.Regenerate();
var actual=fi.LookupParameter("圓形套管直徑").AsDouble()*304.8;
if(Math.Abs(actual-diameter)>0.001||fi.LookupParameter("牆厚度").IsReadOnly||fi.LookupParameter("圓形牆開口流水號").AsInteger()!=(int)diameter||fi.LookupParameter("位置").AsString()!="FL1"||fi.LookupParameter("專業代碼").AsString()!="TYBIM-TEST")throw new Exception("Write verification failed");
checks.Add(new{diameter=actual,thickness=fi.LookupParameter("牆厚度").AsDouble()*304.8,serial=fi.LookupParameter("圓形牆開口流水號").AsInteger(),bottom=fi.LookupParameter("圓形套管底部高程").AsString(),location=fi.LookupParameter("位置").AsString(),code=fi.LookupParameter("專業代碼").AsString(),type=fi.Name,manufacturer=symbol.get_Parameter(BuiltInParameter.ALL_MODEL_MANUFACTURER).AsString()});
}tx.Commit();}
group.RollBack();
}
return new{passed=true,checks,retainedModelChanges=false,scope="Family load, placement, named parameter writes; no full automatic clash detection test"};
}catch(Exception ex){return new{passed=false,error=ex.ToString()};}
